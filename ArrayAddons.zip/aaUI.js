
$(document).ready(function(){
  var ar = AutoReload.Start({latencyId:"ARtimer"});  
  DoTests();
});

function A2S(A){
  return '['+A.join(',')+']';
}
  
// Compares consecutive blue and brown results and gives a tick
// or cross to the brown depending on matching strings
function Result(Title,Expected,Actual){
  var tick,cl,val,e,a;
  e = A2S(Expected);
  a = A2S(Actual);
  if(e == a){
    cl = 'bggrn';
    tick = 'tick1';
    val = a;
  }else{    
    cl = 'bgpnk';
    tick = 'tick0';
    val = 'Expected:'+e+'<br>Actual:'+a;
  }    
  
  $('#results').append('<div class="frame1 round1 pre '+cl+'"><div class="center black bggry"><span class="'+tick+'"> '+Title+'</span></div>'+val+'</div>');
}



function DoTests(){  
  var r;
  var a = [1,3];
  var b = [3,4];
  b.forEach(function(B){
    a.append(B);
  });  
  Result('append',[1,3,4],a); 

  //-------------------------------------------
  
  var c=[1,2,3,7];
  a.concatExtra(c);
  Result('concatExtra',[1,3,4,2,7],a); 

  a.concatExtra([]);
  Result('concatExtra',[1,3,4,2,7],a); 

  a.concatExtra('foo');
  Result('concatExtra',[1,3,4,2,7,'foo'],a); 
  
  
  //-------------------------------------------
  
  a.remove(V=>(V % 2==0));
  Result('remove(function)',[1,3,7,'foo'],a); 
  
  a = [1,2,3,4,5,6,7,8,9];
  a.remove(1);
  a.remove(9);
  a.remove(5);
  Result('remove(value)',[2,3,4,6,7,8],a); 

  a = [];
  a.remove(1);
  Result('remove(value)',[],a); 
  
  //-------------------------------------------
  
  a = [1,2,3,4,5,6,7,8,9];
  a.unconcat([7,4,3,7,8]);
  Result('unconcat',[1,2,5,6,9],a); 
  
  //-------------------------------------------
  
  a = [1,2,3,4,5,6,7,8,9];
  a.substitute(1,'One');
  r = a.substitute(9,'Nine');
  a.push(r);
  r = a.substitute(10,'Ten');   // false
  a.push(r);
  r = a.substitute('Nine','IX');
  a.push(r);
  Result('substitute',['One',2,3,4,5,6,7,8,'IX',true,false,true],a); 

  //-------------------------------------------
  
  a = [1,2,3,4,5,6,7,8,9];
  r = a.insert('9extra',9);
  a.push(r);
  r = a.insert('10extra',10);
  a.push(r);  // fail
  r = a.insert('5extra',V=>(V%5==0));
  a.push(r);  
  r = a.insert('1extra',1);
  a.push(r);  
  r = a.insert('4before',4,true);
  a.push(r);  
  Result('insert',[1,'1extra',2,3,'4before',4,5,'5extra',6,7,8,9,'9extra',true,false,true,true,true],a); 
  

  //-------------------------------------------

  a = [1,2,3,4,5];
  b = [6,5,4];
  var i1 = a.intersection(b);
  var i2 = b.intersection(a);
  Result('intersection',[4,5,5,4],i1.concat(i2));
  
  //-------------------------------------------

  a = [1,2,3,4,5];
  r = a.missingFrom([1,3,5]);
  Result('missingFrom',[2,4],r)
  
  r = a.missingFrom([]);
  Result('missingFrom',a,r)
  
  r = a.missingFrom([5,4,3,2,1]);
  Result('missingFrom',[],r)
  
  //-------------------------------------------
  
  a = [1,2,2,3,1,1];
  a.deduplicate();
  Result('deduplicate',[1,2,3],a);
  
  a = [1,1,1,1,1];
  a.deduplicate();
  Result('deduplicate',[1],a);
  
  a = [1,2,2];
  a.deduplicate();
  Result('deduplicate',[1,2],a);
  
  a = [];
  a.deduplicate();
  Result('deduplicate',[],a);
  
  
  // SORT EXTENDED
  //==================================================================  
  a = [];
  a.push(['Peter',1957,'Edwin']);
  a.push(['Sally',1959,'Jean']);
  a.push(['Geoffrey',1961,'Alan']);
  a.sortOnField(0);
  Result('name sort',['Geoffrey','Peter','Sally'],a.map(V=>V[0]));
  a.sortOnField(1);
  Result('DOB sort',['Peter','Sally','Geoffrey'],a.map(V=>V[0]));
  a.sortOnField(2);
  Result('name sort',['Geoffrey','Peter','Sally'],a.map(V=>V[0]));
  
  a = a.map(function(A){return {name:A[0],middle:A[2],dob:A[1]};});
  a.sortOnField('dob');
  Result('DOB sort',['Peter','Sally','Geoffrey'],a.map(V=>V.name));
  a.sortOnField('name');
  Result('name sort',['Geoffrey','Peter','Sally'],a.map(V=>V.name));
  a.sortOnField('middle');
  Result('middle name',['Geoffrey','Peter','Sally'],a.map(V=>V.name));
  
  
  
};


